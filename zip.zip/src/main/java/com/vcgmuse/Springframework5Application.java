package com.vcgmuse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springframework5Application {

	public static void main(String[] args) {
		SpringApplication.run(Springframework5Application.class, args);
	}

}
