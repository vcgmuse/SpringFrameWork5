package com.vcgmuse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springframework5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
